package com.example.employee.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDto {

    private int employeeId;

    @NotEmpty
    @Size(min = 5,max = 20, message = "Name must be of 5 characters and maximum of 20 characters")
    private String employeeName;

    @NotEmpty
    private String gender;
}
